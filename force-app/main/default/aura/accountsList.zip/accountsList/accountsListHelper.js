({
    getAccList : function( component,event,helper) {
        var action=component.get('c.accListData');
        action.setCallback(this, function(response){
            var state=response.getState();
            if(state == "SUCCESS"){
                var result=response.getReturnValue();
                component.set('v.account',result);
            }
        });
        $A.enqueueAction(action);
    },
    getAccField : function(component,event,helper){
        const columns = [
            {label:'Id', fieldName:'Id'},
            {label:'Account Name', fieldName:'Name'}
        ]
        component.set('v.mycolumns',columns);
    }
})
