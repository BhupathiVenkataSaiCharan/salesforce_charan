({
    doInit : function(component, event, helper) {
        helper.getAccList(component);
        helper.getAccField(component);
    }
})
